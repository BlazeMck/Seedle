const form = document.querySelector('form');

//Class for building every crop and their respective attributes
class Crop {
    constructor(name, season, cost, value, time, energy, health) {
        this.name = name;
        this.season = season;
        this.cost = cost;
        this.value = value;
        this.time = time;
        this.energy = energy;
        this.health = health;
    }
}

//Building objects for every available crop to guess
const blueJazz = new Crop('Blue Jazz', 'Spring', 30, 50, 7, 45, 20);
const carrot = new Crop('Carrot', 'Spring', 0, 35, 3, 75, 33);
const cauliflower = new Crop('Cauliflower', 'Spring', 80, 175, 12, 75, 33);
const coffeeBean= new Crop('Coffee Bean', 'Spring', 2500, 15, 10, 0, 0);
const garlic = new Crop('Garlic', 'Spring', 40, 4, 60, 20, 9);
const greenBean = new Crop('Green Bean', 'Spring', 60, 40, 10, 25, 11);
const kale = new Crop('Kale', 'Spring', 70, 110, 6, 50, 22);
const parsnip = new Crop('Parsnip', 'Spring', 20, 35, 4, 25, 11);
const potato = new Crop('Potato', 'Spring', 50, 80, 6, 25, 11);
const rhubarb = new Crop('Rhubarb', 'Spring', 100, 220, 13, 0, 0);
const strawberry = new Crop('Strawberry', 'Spring', 100, 120, 8, 50, 22);
const tulip= new Crop('Tulip', 'Spring', 20, 30, 6, 45, 20);
const unmilledRice= new Crop('Unmilled Rice', 'Spring', 40, 30, 6, 3, 1);
const ancientFruit = new Crop('Ancient Fruit', 'Spring', 0, 550, 28, 0, 0);
const blueberry = new Crop('Blueberry', 'Summer', 80, 13, 50, 25, 11);
const corn = new Crop('Corn', 'Summer', 150, 50, 14, 25, 11);
const hops = new Crop('Hops', 'Summer', 60, 25, 11, 45, 20);
const hotPepper = new Crop('Hot Pepper', 'Summer', 40, 40, 5, 13, 5);
const melon = new Crop('Melon', 'Summer', 80, 250, 12, 113, 50);
const poppy = new Crop('Poppy', 'Summer', 100, 140, 7, 45, 20);
const radish = new Crop('Radish', 'Summer', 40, 90, 6, 45, 20);
const redCabbage = new Crop('Red Cabbage', 'Summer', 100, 260, 9, 75, 33);
const starfruit = new Crop('Starfruit', 'Summer', 400, 750, 13, 125, 56);
const summerSpangle = new Crop('Summer Spangle', 'Summer', 50, 90, 8, 45, 20);
const summerSquash = new Crop('Summer Squash', 'Summer', 0, 45, 6, 63, 28);
const sunflower = new Crop('Sunflower', 'Summer', 200, 80, 8, 45, 20);
const tomato = new Crop('Tomato', 'Summer', 50, 60, 11, 20, 9);
const wheat = new Crop('Wheat', 'Summer', 10, 25, 4, 0, 0);
const pineapple = new Crop('Pineapple', 'Summer', 0, 300, 14, 138, 62);
const taroRoot= new Crop('Taro Root', 'Summer', 0, 100, 7, 38, 17);
const amaranth = new Crop('Amaranth', 'Fall', 70, 150, 7, 50, 22);
const artichoke = new Crop('Artichoke', 'Fall', 30, 160, 8, 30, 13);
const beet = new Crop('Beet', 'Fall', 20, 100, 6, 30, 13);
const bokChoy = new Crop('Bok Choy', 'Fall', 50, 80, 4, 25, 11);
const broccoli = new Crop('Broccoli', 'Fall', 0, 70, 8, 63, 28);
const cranberries = new Crop('Cranberries', 'Fall', 240, 75, 7, 38, 17);
const eggplant = new Crop('Eggplant', 'Fall', 20, 60, 5, 20, 9);
const fairyRose = new Crop('Fairy Rose', 'Fall', 200, 290, 12, 45, 20);
const grape = new Crop('Grape', 'Fall', 60, 10, 80, 38, 17);
const pumpkin = new Crop('Pumpkin', 'Fall', 100, 320, 13, 0, 0);
const yam = new Crop('Yam', 'Fall', 60, 160, 10, 45, 20);
const sweetGemBerry = new Crop('Sweet Gem Berry', 'Fall', 1000, 3000, 24, 0, 0);
const powdermelon = new Crop('Powder Melon', 'Winter', 0, 60, 7, 63, 28);

const answerArray = [blueJazz, carrot, cauliflower, coffeeBean, garlic, greenBean, kale, parsnip, potato, rhubarb, strawberry, tulip, unmilledRice, ancientFruit, 
    blueberry, corn, hops, hotPepper, melon, poppy, radish, redCabbage, starfruit, summerSpangle, summerSquash, sunflower, tomato, wheat, pineapple, taroRoot,
    amaranth, artichoke, beet, bokChoy, broccoli, cranberries, eggplant, fairyRose, grape, pumpkin, yam, sweetGemBerry, powdermelon];

form.addEventListener('submit', e => {

    e.preventDefault();
    console.log(form.guess.value);
    Crop.forEach(element, index => {
        if (element.name === form.guess.value) {
            console.log(element.season);
        }
    });
});